<?php include 'include/topber.php';?>
<?php include 'include/sideber.php';?>
<style>
    #wrap { width: 1000px; height: 245px; left: 7px; top: 30px; overflow: hidden; }
    #frame { width: 1433px; height: 424px; position: relative; left: -1px; top: -50px; }
    #frame { -ms-zoom: 0.7; -moz-transform: scale(0.7); -moz-transform-origin: 0px 0; -o-transform: scale(0.7); -o-transform-origin: 0 0; -webkit-transform: scale(0.7); -webkit-transform-origin: 0 0; }
</style>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-dashboard"></i> Dashboard</h1>
          <p>VPN GURU SERVER MANAGEMENT SYSTEM</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
        </ul>
      </div>
      <div class="row">
        <div class="col-md-6 col-lg-3">
		
          <div class="widget-small primary btn btn-primary" onclick="window.location.href = 'badvpnstart.php';"><i class="icon fa fa-users fa-3x"></i>
            <div class="info">
              <h4>VPN</h4>
			  <p><b>REBOOT</b></p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small info btn btn-info" onclick="window.location.href = 'badvpnstart.php';"><i class="icon fa fa-thumbs-o-up fa-3x"></i>
            <div class="info">
              <h4>PROXY</h4>
			  <p><b>REBOOT</b></p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small warning btn btn-warning" onclick="window.location.href = 'badvpnstart.php';"><i class="icon fa fa-files-o fa-3x"></i>
            <div class="info">
              <h4>SSL</h4>
			  <p><b>REBOOT</b></p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small danger btn btn-danger" onclick="window.location.href = 'badvpnstart.php';"><i class="icon fa fa-star fa-3x"></i>
            <div class="info">
              <h4>SSL</h4>
			  <p><b>START</b></p>
            </div>
          </div>
        </div>
		        <!--<div class="col-md-6 col-lg-3">
		
          <div class="widget-small primary btn btn-primary" onclick="window.location.href = 'badvpnstart.php';"><i class="icon fa fa-users fa-3x"></i>
            <div class="info">
              <h4>UDP STOP</h4>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small info btn btn-info" onclick="window.location.href = 'badvpnstart.php';"><i class="icon fa fa-thumbs-o-up fa-3x"></i>
            <div class="info">
              <h4>UDP START</h4>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small warning btn btn-warning" onclick="window.location.href = 'badvpnstart.php';"><i class="icon fa fa-files-o fa-3x"></i>
            <div class="info">
              <h4>SSH REBOOT</h4>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small danger btn btn-danger" onclick="window.location.href = 'badvpnstart.php';"><i class="icon fa fa-star fa-3x"></i>
            <div class="info">
              <h4>REBOOT</h4>
            </div>
          </div>
        </div>
      </div>-->
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <h3 class="tile-title">Server Report</h3>
			<div id="wrap">
    <iframe id="frame" src="http://46.17.99.2/mrtg/" scrolling="no"></iframe></div>
			
          </div>
        </div>
      </div>
    </main>
    <?php include 'include/footer.php';?>