<?php

$output = shell_exec("sudo /root/reboot.sh");
echo "<pre>$output</pre>"
?>
