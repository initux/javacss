<?php

$output = shell_exec("sudo /root/squidrestart.sh");
echo "<pre>$output</pre>"
?>
