<?php

    /*$server = "46.17.99.233";

    $check = @fsockopen($server, 22);

    if ($check) {
        @fclose($check);
        echo "online";
        exit;
    }else{
        echo "offline";
    }*/
	
	if (!$socket = @fsockopen("46.17.99.2", 22, $errno, $errstr, 30))
{
  echo "Offline!";
}
else 
{
  echo "Online!";

  fclose($socket);
}

?>