<?php

$output = shell_exec("sudo /root/sshrestart.sh");
echo "<pre>$output</pre>"
?>
