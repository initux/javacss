<?php

$output = shell_exec("sudo /root/badvpnstart.sh");
echo "<pre>$output</pre>"
?>
