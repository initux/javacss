<?php

$output = shell_exec("sudo /root/badvpnstop.sh");
echo "<pre>$output</pre>"
?>
