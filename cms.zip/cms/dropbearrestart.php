<?php

$output = shell_exec("sudo /root/dropbearrestart.sh");
echo "<pre>$output</pre>"
?>
